package Gess.Core;

import java.util.Scanner;

public class HUPlayer extends Player {

	public final Stone stone;
	public Scanner sc;
	
	public HUPlayer(Stone stone, Scanner sc)
	{
		this.stone = stone;
		this.sc =  sc;
	}
	
	private Unit selectUnit(Game game, Scanner sc) throws IllegalArgumentException //maybe refactor to chooseUnit
	{
		System.out.println("Enter an int for x : ");
		int x = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter an int for y : ");
		int y = sc.nextInt();
		sc.nextLine();
		return game.getCurrentBd().getUnit(x, y);
	}
	private Unit choosePiece(Game game, Move move)
	{
		System.out.println("Choose a valid piece : ");
		Unit unit = selectUnit(game, this.sc);
		try {
			move.selectPiece(game, unit);
		} 
		catch (IllegalArgumentException e)
		{
			System.out.println(e.getMessage());
			choosePiece(game, move);
		}
		return unit;
	}
	public void chooseDest(Game game, Move move)
	{
		System.out.println("Choose a valid destination");
		Unit dest = selectUnit(game,this.sc);
		try 
		{
			move.selectDest(game, dest.getPos().x, dest.getPos().y);
		} 
		catch (IllegalArgumentException e)
		{
			System.out.println(e.getMessage());
			chooseDest(game, move);
		}
	}
	
	public void playTurn(Game game)
	{
		System.out.println("It is " + this.stone +"'s turn.");
		boolean hasMoved = false;
		Move move = new Move();
		while (!hasMoved)
		{
			System.out.println(game.getCurrentBd().toGameString());
			while (!move.hasChosenPiece())
			{
				this.choosePiece(game, move);
			}
			while (move.hasChosenPiece() && !move.hasChosenDest()){
				System.out.println("MoveSpace : \n" + move.getChosenPiece().getMvSp().toGameString());
				System.out.println("Undo selection 'U' or chose destination 'D' : ");
				String choice = sc.next();
				if (choice.equals("U")) {
					move.deselectPiece(); 
					break;
				}
				else 
				{
					while (!move.hasConfirmedMove()) 
					{
						while(!move.hasChosenDest())
						{
							this.chooseDest(game, move);
						}
						move.buildFutureBd(stone,game.getCurrentBd()); //this can't fail because of previous checks while choosing dest and piece
						//however, for clarity purposes, we don't want the changed board to show if the move is invalid
						if (move.isValid(game)) System.out.println("Future board : \n" + move.getFutureBd().toGameString());
						else 					System.out.println("Watch out, move is invalid.");
						System.out.println("\nMove is : " + move.getChosenPiece().getUnit() + " to " + move.getChosenDest());
						
						
						choice = "0";
						while (!(choice.equals("C") || choice.equals("D") || choice.equals("U")))
						{
							System.out.println("Undo both selections 'U', undo destination 'D', or confirm move 'C' : ");
							choice = this.sc.next();
							System.out.println("Choice : " + choice);
						}
					
						if (choice.equals("D")) 
						{
							move.deselectDest();
							break;
						}
						if (!move.isValid(game)) 
						{
							System.out.println("Not a valid move, cannot : pass, ko-loop, suicide, pick Dest out of MoveSpace.");
							choice = "U";
						}
						if (choice.equals("U")) 
						{
							move.deselectDest();
							move.deselectPiece();
							break;
						}
						else move.confirmMove();
					}
				}
			}				
			hasMoved = move.hasConfirmedMove();
		}
		game.update(move.getFutureBd());
	}
	
	public Stone getStone()
	{
		return this.stone;
	}
}
