package Gess.Core;

import java.util.HashSet;


public class Piece {
	
	private Stone stone;
	private HashSet<Direction> dirSet;
	private NeighborHood neighborHood;
	private boolean hasCenter;
	private Pair<Integer,Integer> pos;
	private MoveSpace mvSp;
	private Unit centerUnit;
	
	
	public Piece (Unit unit, Stone stone, Board bd)
	{	//remember to check the validity of the footprint to be played before this constructor is called in the game loop
		HashSet<Direction> dirSet = new HashSet<Direction>();
		boolean center = false;
		for (int y=0; y <= 2; y++)
		for (int x=0; x <= 2; x++)
		{
			if (unit.getFP().getStone(x, y).equals(stone)) 
			{
				if (y==0 || y == 2 || x == 0 || x == 2) dirSet.add(Direction.fpToDir(x,y));
				else center = true; 
			}
		}
		this.centerUnit = unit;
		this.stone = stone; 
		this.dirSet = dirSet;
		this.hasCenter = center;
		this.pos = unit.getPos();
		this.neighborHood = unit.getNH(); 
		this.mvSp = new MoveSpace(this, bd);
	}
	public Piece (Piece piece) 
	{
		this.stone = piece.getStone();
		this.dirSet = piece.getDirSet();
		this.neighborHood = piece.getNH();
		this.hasCenter = piece.hasCentralStone();
		this.pos = piece.getPos();
		this.mvSp = piece.getMvSp();
		this.centerUnit = piece.getUnit();
	}

	
	public HashSet<Direction> getDirSet() 
	{
		return this.dirSet;
	}
	public boolean hasCentralStone()
	{
		return this.hasCenter;
	}
	public Pair<Integer,Integer> getPos() 
	{
		return this.pos;
	}
	public NeighborHood getNH() 
	{
		return this.neighborHood;
	}
	public Stone getStone()
	{
		return this.stone;
	}
	public Unit getUnit()
	{
		return this.centerUnit;
	}
	public MoveSpace getMvSp()
	{
		return this.mvSp;
	}
	
	public String toString()
	{
		StringBuilder str = new StringBuilder("");
		int i = 0;
		for (Direction dir : Direction.values())
		{
			i++;
			HashSet<Direction> dirSet = this.getDirSet();			
			if (dirSet.contains(dir)) str.append(this.getStone().toString());
			else if (dir.equals(Direction.Ce) && this.hasCenter) str.append(this.stone.toString());
			else if (dir.equals(Direction.Er) && i < 10) str.append("r");
			else if (dir.equals(Direction.Er) && i == 10); //the last dir is necessarily Er
			else str.append(".");
			if (i % 3 == 0) str.append("\n");
		}
		return str.toString();		
	}

}
