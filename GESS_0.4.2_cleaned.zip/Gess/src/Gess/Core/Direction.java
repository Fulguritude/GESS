package Gess.Core;


/**
 * Enum class to help build the MoveSpace class
 * @author fulguritude
 *
 */

public enum Direction {
	TL,
	TM,
	TR,
	ML,
	Ce, ///center stone
	MR,
	BL,
	BM,
	BR,
	Er; //error

	public static Direction fpToDir(int x, int y)
	{
		//System.out.println("Direction fpToDir" + new Pair<Integer,Integer>(x,y) );
		switch (y)
		{
		case 0 : switch (x) 
				 {
				 case 0 : return TL;
				 case 1 : return TM;
				 case 2 : return TR;
				 default : break;
				 }
		case 1 : switch (x) 
		 		 {
		 		 case 0 : return ML;
		 		 case 1 : return Ce;
		 		 case 2 : return MR;
		 		 default : break;
		 		 }
		case 2 :switch (x) 
				{
				case 0 : return BL;
				case 1 : return BM;
				case 2 : return BR;
				default : break;
				}
		default : return Er;
		}
	}
	
	public String toString()
	{
		switch (this)
		{
		case BL: return "BL"; 
		case BM: return "BM"; 
		case BR: return "BR"; 
		case Ce: return "Ce"; 
		case ML: return "ML"; 
		case MR: return "MR"; 
		case TL: return "TL"; 
		case TM: return "TM"; 
		case TR: return "TR"; 
		default: return "Er"; 
		}
		
	}
}
