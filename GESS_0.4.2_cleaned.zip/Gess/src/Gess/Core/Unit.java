package Gess.Core;

import Gess.Core.Pair;

public class Unit {
	

	private Pair<Integer,Integer> pos;
	private NeighborHood nbHood;
	private Stone stone;
	private Board bd;
	private FootPrint fp;
	
	private NeighborHood checkNbHood() 
	{
		//pas de break ici car on a return automatique
		switch (pos.y) 
		{
			case 0  : switch (pos.x) {
				case 0  : return NeighborHood.TLeC;
				case 17 : return NeighborHood.TRiC;
				default : return NeighborHood.TMid;
			}
			case 17 : switch (pos.x) {
				case 0  : return NeighborHood.BLeC;
				case 17 : return NeighborHood.BRiC;
				default : return NeighborHood.BMid;
			}
			default : switch (pos.x) {
				case 0  : return NeighborHood.MLeF;
				case 17 : return NeighborHood.MRiF;
				default : return NeighborHood.Norm;
			}
		}
	}
	
	public Unit (int x, int y, Stone stone, Board bd) 
	{
		this.pos = new Pair<Integer,Integer>(x,y);
		this.nbHood = checkNbHood();
		this.stone = stone;
	}
	public Unit (Unit unit, Board bd)
	{
		this.stone = unit.getStone();
		this.nbHood = unit.getNH();
		this.pos = unit.getPos();
		unit.setBoardInfo(bd);
	}
	public void setBoardInfo(Board bd)
	{
		this.bd = bd;
		this.fp = new FootPrint(this, bd); //new Board(bd) ? Probably not worth it, unlike movespace
	}
	
	public Stone getStone()
	{ //getStone from unit needs no argument
		return this.stone;
	}
	public void setStone(Stone stone)
	{
		this.stone = stone;
	}
	public Pair<Integer,Integer> getPos() {
		return this.pos;
	}
	public FootPrint getFP()
	{
		return this.fp; 
	}
	public NeighborHood getNH()
	{
		return this.nbHood;
	}
	
	
	public String toString()
	{
		return this.pos.toString();
	}
	public String toStoneAsString ()
	{
		switch (this.getStone()) 
		{	
			case B : return "B"; 
			case W : return "W"; 
			case E : return "E"; 
			default : return "O"; 
		}
			
	}
}
