/*
 List<List<String>> listOfLists = new ArrayList<List<String>>();

And then when you needed to add a new "row", you'd add the list:

listOfLists.add(new ArrayList<String>());
 */

//idea for when coding this in C or C++ for speedups : 
//for the board datatype, make two series of 18*18 bits, 
//one white stones, the other indicates black stones
//and an "bitwise or" creates a list of stones. 
//checking for overlap would be much simpler ; an "and" etc.
//movement could be done with some adequate bitshifting


package Gess.Core;

import java.util.ArrayList;


public class Board {
	

	public static final Board startConfig = new Board 
		( new String[]{
				"EWEWEWWWWWWWWEWEWE",
				"WWWEWEWWWWEWEWEWWW",
				"EWEWEWWWWWWWWEWEWE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EWEEWEEWEEWEEWEEWE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EBEEBEEBEEBEEBEEBE",
				"EEEEEEEEEEEEEEEEEE",
				"EEEEEEEEEEEEEEEEEE",
				"EBEBEBBBBBBBBEBEBE",
				"BBBEBEBBBBEBEBEBBB",
				"EBEBEBBBBBBBBEBEBE"}
		);
			
	private ArrayList<ArrayList<Unit>> layout = new ArrayList<ArrayList<Unit>>();
	private int blackKings;
	private int whiteKings;

	
	
	public static boolean inBounds (int x, int y)
	{
		return x >= 0 && x <= 17 && y >= 0 && y <= 17;
	}

	/**
	 * Constructors and private Constructor "helper methods"
	 */
	public Board(String[] rows) 
	{
		this.layout = convertStrToBoard(rows);
		for (int y = 0; y <= 17; y++)
		{
			for (int x = 0; x <= 17; x++)
			{
				this.layout.get(y).get(x).setBoardInfo(this);
			}
		}
		this.setKingCount();
	}
	public Board (ArrayList<ArrayList<Unit>> layout)
	{
		this.layout = new ArrayList<ArrayList<Unit>>(layout);
		this.setKingCount();
		//System.out.println(this.layout); NOT READ
	}
	public Board (Board bd)
	{
		//System.out.println(this); READ
		ArrayList<ArrayList<Unit>> layout = new ArrayList<ArrayList<Unit>>();
		for (int y = 0; y <= 17; y++)
		{
			ArrayList<Unit> row = new ArrayList<Unit>();
			for (int x = 0; x <= 17; x++)
			{
				Unit unit = new Unit(bd.getUnit(x, y), bd);
				row.add(unit);
			}
			layout.add(row);
		}
		this.layout = layout;
		for (int y = 0; y <= 17; y++)
		{
			for (int x = 0; x <= 17; x++)
			{
				layout.get(y).get(x).setBoardInfo(this);
			}
		}
		this.setKingCount();
	}

	private ArrayList<ArrayList<Unit>> convertStrToBoard (String[] tokens) 
	{
		//the str format convention is 18 letters representing each row, 18 strings, 1 per row
		//B for Black, W for White, E for Empty
		ArrayList<ArrayList<Unit>> board = new ArrayList<ArrayList<Unit>>();
		//String[] tokens = str.split(" ");
		for (int y=0; y <= 17 ;y++) 
		{
			ArrayList<Unit> row = new ArrayList<Unit>();
			for (int x=0; x <= 17 ;x++) 
			{
				switch (tokens[y].charAt(x)) 
				{
					//The this serves to link each Unit to a given Board, in order to define its FootPrint
					//The Board is a matrix of Units 
					//The FootPrint of each unit depends on the board configuration  
					case 'B' : row.add(new Unit(x,y, Stone.B, this));break;
					case 'W' : row.add(new Unit(x,y, Stone.W, this));break;
					case 'E' : row.add(new Unit(x,y, Stone.E, this));break;
				}
			}
			board.add(row);
		}
		return board;
	}
	private void setKingCount()
	{
		for (int y = 1; y <= 16; y++) //2to17 because only Norm neighborhoods can be kings
		for (int x = 1; x <= 16; x++)
		{
			if (this.getUnit(x,y).getFP().isKing(Stone.B)) this.blackKings++;
			else 
			if (this.getUnit(x,y).getFP().isKing(Stone.W)) this.whiteKings++;
		}
	}
	
	/**
	 * Methods for creating altered boards
	 */
	public static Board bdWOpiece(Board bd, Piece piece)
	{
		Board bdWOpiece = new Board(bd);
		int x = piece.getPos().x;
		int y = piece.getPos().y;
		switch (piece.getNH())
		{
		case TLeC: {bdWOpiece.setStone(x  ,y  ,Stone.E); bdWOpiece.setStone(x+1,y  ,Stone.E);
					bdWOpiece.setStone(x  ,y+1,Stone.E); bdWOpiece.setStone(x+1,y+1,Stone.E); break;}
		
		case TMid: {bdWOpiece.setStone(x-1,y  ,Stone.E); bdWOpiece.setStone(x  ,y  ,Stone.E); bdWOpiece.setStone(x+1,y  ,Stone.E);
					bdWOpiece.setStone(x-1,y+1,Stone.E); bdWOpiece.setStone(x  ,y+1,Stone.E); bdWOpiece.setStone(x+1,y+1,Stone.E);break;}
		
		case TRiC: {bdWOpiece.setStone(x-1,y  ,Stone.E); bdWOpiece.setStone(x  ,y  ,Stone.E); 
					bdWOpiece.setStone(x-1,y+1,Stone.E); bdWOpiece.setStone(x  ,y+1,Stone.E); break;}
		
		case MLeF: {bdWOpiece.setStone(x  ,y-1,Stone.E); bdWOpiece.setStone(x+1,y-1,Stone.E);
					bdWOpiece.setStone(x  ,y  ,Stone.E); bdWOpiece.setStone(x+1,y  ,Stone.E);
					bdWOpiece.setStone(x  ,y+1,Stone.E); bdWOpiece.setStone(x+1,y+1,Stone.E); break;}
		
		case Norm: {bdWOpiece.setStone(x-1,y-1,Stone.E); bdWOpiece.setStone(x  ,y-1,Stone.E); bdWOpiece.setStone(x+1,y-1,Stone.E);
					bdWOpiece.setStone(x-1,y  ,Stone.E); bdWOpiece.setStone(x  ,y  ,Stone.E); bdWOpiece.setStone(x+1,y  ,Stone.E);
					bdWOpiece.setStone(x-1,y+1,Stone.E); bdWOpiece.setStone(x  ,y+1,Stone.E); bdWOpiece.setStone(x+1,y+1,Stone.E);break;}
		
		case MRiF: {bdWOpiece.setStone(x-1,y-1,Stone.E); bdWOpiece.setStone(x  ,y-1,Stone.E); 
					bdWOpiece.setStone(x-1,y  ,Stone.E); bdWOpiece.setStone(x  ,y  ,Stone.E); 
					bdWOpiece.setStone(x-1,y+1,Stone.E); bdWOpiece.setStone(x  ,y+1,Stone.E); break;}
		
		case BLeC: {bdWOpiece.setStone(x  ,y-1,Stone.E); bdWOpiece.setStone(x+1,y-1,Stone.E);
					bdWOpiece.setStone(x  ,y  ,Stone.E); bdWOpiece.setStone(x+1,y  ,Stone.E); break;}
		
		case BMid: {bdWOpiece.setStone(x-1,y-1,Stone.E); bdWOpiece.setStone(x  ,y-1,Stone.E); bdWOpiece.setStone(x+1,y-1,Stone.E);
					bdWOpiece.setStone(x-1,y  ,Stone.E); bdWOpiece.setStone(x  ,y  ,Stone.E); bdWOpiece.setStone(x+1,y  ,Stone.E); break;}
		
		case BRiC: {bdWOpiece.setStone(x-1,y-1,Stone.E); bdWOpiece.setStone(x  ,y-1,Stone.E); 
					bdWOpiece.setStone(x-1,y  ,Stone.E); bdWOpiece.setStone(x  ,y  ,Stone.E); break;}
		}
		
		for(int i = 0; i <= 4; i++)
		for(int j = 0; j <= 4; j++)
		{
			if (inBounds(x-2+j,y-2+i)) bdWOpiece.getUnit(x - 2 + j, y - 2 + i).setBoardInfo(bdWOpiece);
		}
		
		return bdWOpiece;
	}
	public void setPieceAt(FootPrint mergedFP, Integer xPos, Integer yPos) {
		//etape 1 : changer toutes les stones
		//etape 2 : setBoardInfo sur les cases à updater
		
		for(int y = 0; y <= 2; y++)
		for(int x = 0; x <= 2; x++)
		{
			if (!mergedFP.getStone(x, y).equals(Stone.O)) this.setStone(xPos - 1 + x, yPos - 1 + y, mergedFP.getStone(x, y));
		}
		for(int y = 0; y <= 4; y++)
		for(int x = 0; x <= 4; x++)
		{
			if (inBounds(xPos-2+x,yPos-2+y)) this.getUnit(xPos - 2 + x, yPos - 2 + y).setBoardInfo(this);
		}

	}
	
	
	public boolean checkWin(Stone stone)  
	{   //returns true if the current player has just killed the opponent's last king
		if (stone.equals(Stone.B)) return this.whiteKings == 0;
		if (stone.equals(Stone.W)) return this.blackKings == 0;
		return false;
	}

	
	public ArrayList<ArrayList<Unit>> getLayout()
	{
		return this.layout;
	}
	public Unit getUnit(int x,int y) throws IllegalArgumentException
	{
		if (!inBounds(x,y)) throw new IllegalArgumentException("Coordinates not in bounds : x,y must be in [[0-17]]");
		return this.layout.get(y).get(x);
	}
	public Stone getStone (int x, int y)
	{ //getStone from Board takes 2 arguments
		return this.getUnit(x,y).getStone();
	}
	public void setStone(int x, int y, Stone stone)
	{
		this.getUnit(x, y).setStone(stone);
	}	
	public int getKingNb(Stone stone)
	{
		return stone.equals(Stone.B) ? blackKings : whiteKings;
	}
	
	/**
	 * @return a String for Board manipulation
	 */
	public String toString()  
	{
		StringBuffer str = new StringBuffer("");
		for (int y=0;y<=17;y++) 
		{			
			for (int x=0;x<=17;x++)
			{
				str.append(this.getUnit(x, y).toStoneAsString());
			}
			str.append("\n");
		}
		return str.toString();
	}
	/**
	 * @return A visually pleasing text based Board 
	 */
	public String toGameString()  
	{	//makes the board more understandable 
		StringBuffer str = new StringBuffer("y\\x| 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|");
		for (int y=0;y<=17;y++) 
		{	
			//str.append("\n__________________________________________________________\n");
			str.append("\n---+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+\n");
			if (y<10) str.append("  "+y+"|");
			else 	  str.append(" " +y+"|");
			for (int x=0;x<=17;x++)
			{
				String stoneStr = this.getUnit(x, y).toStoneAsString();
				if(!stoneStr.equals("E")) str.append(stoneStr+stoneStr+"|");
				else					  str.append("  |");
			}
		}
		str.append("\n---+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+\n");
		return str.toString();
	}
}


