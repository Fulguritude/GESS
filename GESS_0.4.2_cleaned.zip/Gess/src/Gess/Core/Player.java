package Gess.Core;

public abstract class Player {
	
	public abstract void playTurn(Game game);
}
