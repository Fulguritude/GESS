package Gess.Core;

public class Pair<T,S> {
	public final S x;
    public final T y;

    public Pair(S x, T y) 
    { 
        this.x = x;
        this.y = y;
    }
    
    public String toString() 
    {
    	return "(" + x.toString() + "," + y.toString() + ")";
    }
}

