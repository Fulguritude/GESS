package Gess.Core;

public enum Stone {
	W, //White
	B, //Black
	E, //Empty
	O, //Out-of-bounds, for the footprint
	I; //Invalid, for the opposites and debugging
	

	/**
	 * Deals with proprities when ending a move. 0<=x,y<=2 for any footprint ; returns the resolution of the conflict at (x,y)
	 * @param player  player's stone color ; who is eating whom ?
	 * @param top     player's (x,y) stone on the moving piece/footprint
	 * @param bot     opponent's (x,y) stone on the receiving footprint
	 * @return 		  the end result of the stone at (x,y) after a move is made
	 */
	public static Stone mergeStone(Stone player, Stone top, Stone bot)
	{
		if (player.equals(B))
		{
			switch (top)
			{
			case O : case E: return bot; //if top is empty at (x,y), bot always has priority
			case B :
				switch (bot) 
				{
				case O : 		  			return O; //the sides of your piece can end out of bounds
				case E : case W : case B :  return B; //all other relevant cases are replaced by the player's stone
				default : 		  			return I;
				}
			default : return I;	//no case for player.opp, as you can't ever move another players stones
			}
		}
		
		else if (player.equals(W))
		{
			switch (top)
			{
			case O : case E: return bot;
			case W :
				switch (bot) 
				{
				case O : 		  			return O;
				case E : case W : case B :  return W;
				default : 		  			return I;
				}
			default : return I; 
			}
		}
		
		else {System.out.println("Error in mergeStone : not a valid player stone type"); return I;}
			
	}

	public Stone getOpp()
	{
		if (this.equals(W)) return B;
		if (this.equals(B)) return W;
		else return I;
	}
	
	public String toString() {
		switch (this)
		{
		case B : return "B";
		case W : return "W";
		case E : return "E";
		case O : return "O";
		default : return "I";
		}
	}
	
}
