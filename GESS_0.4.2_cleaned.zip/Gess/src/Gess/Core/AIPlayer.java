package Gess.Core;

 
//TODO, maybe add a distance from center argument to a MvSp unit : the further you go, the more likely you are to reinforce pieces or be attacking the enemy.  


import java.util.ArrayList;
import java.util.Random;

public class AIPlayer extends Player {
	
	/**
	 * Health constants //it seems this actually slows down the software... 
	 */
	
	public static final int CHECKMATE = 2000;
	public static final int KINGSWGHT = 50;
	public static final int STONEWGHT = 10;
	public static final int LASKINGCH = 30;
	public static final int ANYKINGCH = 20;
	public static final int MAXWAIT   = 15;
	
	public final Stone stone;
	private ArrayList<Unit> unitList; //all possible pieces
	private ArrayList<Move> moveList; //all possible moves
	
	
	/**
	 * List unit type center square of all playable pieces
	 * @param game
	 */
	private static ArrayList<Unit> listUnits (Board bd, Stone stone)
	{
		ArrayList<Unit> unitList = new ArrayList<Unit>();
		for (int y = 0; y <= 17; y++)
		for (int x = 0; x <= 17; x++)
		{
			Unit unit = bd.getUnit(x,y); 
			if (unit.getFP().isPiece(stone)) unitList.add(unit);
		}
		//System.out.println(unitList);
		return unitList;
	}
	private static ArrayList<Move> listMoves (Board bd, Stone stone, ArrayList<Unit> unitList)
	{
		ArrayList<Move> moveList = new ArrayList<Move>(); 
		for (int i = 0; i < unitList.size(); i++)
		{
			Piece piece = new Piece(unitList.get(i), stone, bd);
			ArrayList<Pair<Integer,Integer>> movesArr = piece.getMvSp().getArr();
			for (int j = 0; j < movesArr.size(); j++)
			{
				//System.out.println("j = " + j + "   ;   piece at : " + piece.getPos() + "   ;   movesArr[j] = " + movesArr.get(j));
				Unit dest = bd.getUnit(movesArr.get(j).x, movesArr.get(j).y);
				Move move = new Move(bd,piece,dest);
				moveList.add(move); //don't forget to computeHealth for all, sometime later
			}
		}
		return moveList;
	}
	

	/**
	 * Constructor
	 * @param stone
	 */
	public AIPlayer(Stone stone)
	{
		this.stone = stone;
	}
	
	private void update(Game game)
	{
		this.unitList = listUnits(game.getCurrentBd(),this.stone);
		this.moveList = listMoves(game.getCurrentBd(),this.stone, this.unitList);
	}

	private Move selectRandZeroMove(ArrayList<Move> zeroHealthList, Game game)
	{
		Random rand = new Random();
		Move move = new Move();
		for (int i=0; i < 1; i++)
		{
			int r = rand.nextInt(zeroHealthList.size());
			move = zeroHealthList.get(r);
			if (!move.isValid(game)) {zeroHealthList.remove(r); i--;} 
		}
		return move;
	}
	private Move selectCheckmateOrBestMove(Game game)
	{
		Board currntBd = game.getCurrentBd();
		Stone enemy = this.getStone().getOpp();
		Move move;
		int ownCurrRings = currntBd.getKingNb(stone);
		int oppCurrRings = currntBd.getKingNb(enemy);
		
		//Part 1 : checking for a Checkmate or a kingSlay/kingMake ; clean bad king-related moves from moveList 
		System.out.println("Part 1");
		
		Move kingSlayOrMake = null;
		for (int i = 0; i < moveList.size(); i++)
		{
			move = moveList.get(i);
			Board futureBd = move.getFutureBd(); 
			int ownFutuRings = futureBd.getKingNb(stone);
			int oppFutuRings = futureBd.getKingNb(enemy);
			int bonus = computeHealthKings(ownCurrRings, ownFutuRings, oppCurrRings, oppFutuRings); 
			if (bonus == CHECKMATE) return move;
			if (bonus <= -KINGSWGHT) {moveList.remove(i); i--; continue;}
			move.addHealth(bonus);
			try 
			{
				if (bonus > kingSlayOrMake.getHealth() && move.isValid(game)) kingSlayOrMake = move ;
			} 
			catch (NullPointerException e)
			{
				if (bonus >= KINGSWGHT && move.isValid(game)) kingSlayOrMake = move;
			}
		}
		if (!(kingSlayOrMake == null)) return kingSlayOrMake;
		
	
		//Part 2 : Checking stone count ; more cleaning of moveList
		System.out.println("Part 2");
		ArrayList<Move> currEnemyMoves = listMoves(currntBd,enemy,listUnits(currntBd,enemy));
		int currOwnKingsThreatened = countCheckAmount(currEnemyMoves, enemy, ownCurrRings);
		int currOppKingsThreatened = countCheckAmount(moveList, stone, oppCurrRings);
	
		ArrayList<Move> positiveMoves = new ArrayList<Move>();
		for (int i = 0; i < moveList.size();i++)
		{
			move = moveList.get(i);
			int bonus = computeHealthStones(move);
			if (bonus < 0) {moveList.remove(i);							 i--; continue;} //at this point, there are no negative moves in moveList, so no need to move.addHealth
			move.addHealth(bonus);
			if (bonus > 0) {positiveMoves.add(move); moveList.remove(i); i--; continue;}
		}
		if (!positiveMoves.isEmpty())
		{
			for (int i = 0; i < positiveMoves.size(); i++)
			{
				System.out.println("Checking if a positive move puts the enemy in Check or causes SelfCheck. Move " + (i+1) + " of " + positiveMoves.size());
				move = positiveMoves.get(i);
				Board futureBd = move.getFutureBd();
				int ownFutuRings = futureBd.getKingNb(stone);
				int oppFutuRings = futureBd.getKingNb(enemy);
				
				ArrayList<Move> futuEnemyMoves = listMoves(futureBd,enemy,listUnits(futureBd,enemy));
				ArrayList<Move> futuPlayrMoves = listMoves(futureBd,stone,listUnits(futureBd,stone));
				int futuOwnKingsThreatened = countCheckAmount(futuEnemyMoves, enemy, ownCurrRings);
				int futuOppKingsThreatened = countCheckAmount(futuPlayrMoves, stone, oppCurrRings);
				int extraDanger = futuOwnKingsThreatened - currOwnKingsThreatened;
				int extraAttack = futuOppKingsThreatened - currOppKingsThreatened;
				
				
				if (futuOwnKingsThreatened == ownFutuRings) {positiveMoves.remove(i); 	i--; continue;}
				if (futuOppKingsThreatened == oppFutuRings)  move.addHealth(			 LASKINGCH);
				if (extraDanger > 0) 						 move.addHealth(-extraDanger*ANYKINGCH);
				if (extraAttack > 0) 						 move.addHealth( extraAttack*ANYKINGCH);
				
				
				if (move.getHealth() < 0) positiveMoves.remove(i); 
			}
			if (!positiveMoves.isEmpty())
			{
				try 
				{
					move = getBestMove(positiveMoves, game);
					return move;
				}
				catch (IllegalArgumentException e) 
				{
					System.out.println("Elements of the list PositiveMoves were never valid.");
				}
			}
		}
		
		
		//Part 3 : only moves with (health==0) left ; just return the first one that doesn't SelfCheck, with a max wait time of 10 tries
		System.out.println("Part 3");
		ArrayList<Move> zeroHealthList = this.moveList;
		int wait = 0;
		while (wait < MAXWAIT) {
			System.out.println("Checking if a random leftover move puts the enemy in Check or causes SelfCheck. Move " + (wait+1) + " of maxtries = " + MAXWAIT);
			move = selectRandZeroMove(zeroHealthList, game);
			Board futureBd = move.getFutureBd();
			int ownFutuRings = futureBd.getKingNb(stone);
			int oppFutuRings = futureBd.getKingNb(enemy);
			
			ArrayList<Move> futuEnemyMoves = listMoves(futureBd,enemy,listUnits(futureBd,enemy));
			ArrayList<Move> futuPlayrMoves = listMoves(futureBd,stone,listUnits(futureBd,stone));
			int futuOwnKingsThreatened = countCheckAmount(futuEnemyMoves, enemy, ownCurrRings);
			int futuOppKingsThreatened = countCheckAmount(futuPlayrMoves, stone, oppCurrRings);
			int extraDanger = futuOwnKingsThreatened - currOwnKingsThreatened;
			int extraAttack = futuOppKingsThreatened - currOppKingsThreatened;
			
			
			if (futuOwnKingsThreatened == ownFutuRings) {wait++; continue;}
			if (futuOppKingsThreatened == oppFutuRings)  move.addHealth(			 LASKINGCH);
			if (extraDanger > 0) 						 move.addHealth(-extraDanger*ANYKINGCH);
			if (extraAttack > 0) 						 move.addHealth( extraAttack*ANYKINGCH);
			
			
			if (move.getHealth() >= 0) return move;
			else wait++;
		}
		
		System.out.println("No more time. No positive move found. Selecting random valid move.");
		return selectRandZeroMove(zeroHealthList, game);
	}
	
	/**
	 * Checks evolution in number of kings and rewards/punishes appropriately
	 * @param game
	 * @param move
	 * @return
	 */
	private static int computeHealthKings(int oldPlayrRings, int newPlayrRings, int oldEnemyRings, int newEnemyRings)
	{
		int bonus = 0;
		if (newPlayrRings == 0) 		   return  -CHECKMATE; //Easier to check against suicide here, where it costs less than Move.isValid
		if (newEnemyRings == 0)		   	   return   CHECKMATE; //Winning move
		int kingsGained = newPlayrRings - oldPlayrRings;
		int kingsKilled = newEnemyRings - oldEnemyRings;
		if (kingsGained > 0) bonus += KINGSWGHT*kingsGained; //We craft new Kings/Rings
		if (kingsGained < 0) bonus += KINGSWGHT*kingsGained; //We destroy our own Ring(s), + because kingsGained can be negative
		if (kingsKilled > 0) bonus += KINGSWGHT*kingsKilled; //We destroy an/some enemy Ring(s)
		return bonus;
	}
	/**
	 * Count how much enemies are eaten vs self eating
	 * @param currntBd
	 * @param futureBd
	 * @param move
	 * @return bonus
	 */
	private static int computeHealthStones(Move move)
	{	
		int bonus = 0; 
		//losses should always be positive in this context, so that bonus is appropriate 
		bonus -= move.getOwnLoss()*STONEWGHT;
		bonus += move.getOppLoss()*STONEWGHT;
		return bonus;
	}
	/**
	 * From stone's POV : returns max amount of enemy kings in check for a single move ; tests every move
	 * @param moveList stone's moveList
	 * @param stone 
	 * @param enemyKings stoneOpp's number of kings
	 * @return nbEnemiesInCheck ; highest number of kills of all given moves, generally 0 or 1
	 */
	private static int countCheckAmount(ArrayList<Move> moveList, Stone stone, int currntEnemyKings)
	{	
		Stone enemy = stone.getOpp();
		int enemiesInCheck = 0; 
		for(int i=0; i<moveList.size(); i++)
		{ 	
			int futureEnemyKings = moveList.get(i).getFutureBd().getKingNb(enemy);
			int kingsKilled = currntEnemyKings - futureEnemyKings;
			if (kingsKilled > enemiesInCheck) enemiesInCheck = kingsKilled;
		}
		return enemiesInCheck;
	}

	/**
	 * Checks for a mate first
	 */
	public void playTurn(Game game)
	{
		System.out.println(game.getCurrentBd().toGameString());
		System.out.println("It is " + this.stone +"'s turn.");
		System.out.println("COMPUTING MOVE");
		
		this.update(game);
		Move move = selectCheckmateOrBestMove(game);
		
		System.out.println("AI player " + this.stone + "'s move is : " + move);
		System.out.println(move.toFPString());
		System.out.println("Own loss : "   + move.getOwnLoss() + " stones\n" + 
						   "Enemy loss : " + move.getOppLoss() + " stones");
		
		if (move.equals(new Move())) System.out.println("NO VALID MOVE FOUND ERROR.");
		game.update(move.getFutureBd());
	}
	
		
	public Stone getStone()
	{
		return this.stone;
	}
	public static Move getBestMove(ArrayList<Move> moveList, Game game) throws IllegalArgumentException
	{
		int i = 0;
		Move move = new Move();
		while (!move.isValid(game) || move.hasChosenDest() == false)
		{
			move = moveList.get(i);
			i++;
			if(i == moveList.size()) throw new IllegalArgumentException();
		}
		
		int max = move.getHealth();
		for (; i < moveList.size(); i++)
		{
			if (moveList.get(i).getHealth() > max)
			{
				move = moveList.get(i);
				max = move.getHealth();
			}
		}
		return move;
	}
}


