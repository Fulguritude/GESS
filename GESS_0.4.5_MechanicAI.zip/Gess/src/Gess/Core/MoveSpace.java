package Gess.Core;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import Gess.Core.Pair;

public class MoveSpace {

	private Unit centralUnit;
	private ArrayList<Pair<Integer,Integer>> movesArr;	
	
	/**
	 * Constructor, a MoveSpace is defined for single unit and its footprint
	 * @param piece : the piece the MoveSpace of which we're creating
	 * @param bd
	 */
	public MoveSpace (Piece piece, Board bd)
	{	
		this.centralUnit = piece.getUnit();
		if (piece.hasCentralStone()) this.movesArr = extendDirsetToURMS(piece, bd);
		else						 this.movesArr = extendDirsetToR3MS(piece, bd);	
	}
	
	
	private static boolean inRestrict3(int centerX, int centerY, int x, int y)
	{
		return centerX - 3 <= x && x <= centerX + 3 &&  centerY - 3 <= y && y <= centerY + 3;
	}
	private static boolean isOverlap(Board bd, Piece piece, int bx, int by)
	{ 	//top x top y bottom x bottom y
		int tx = piece.getPos().x;
		int ty = piece.getPos().y;
		//System.out.println("bdWOpiece :\n" + Board.bdWOpiece(bd, piece));
		Board movingPieceBd = new Board(Board.bdWOpiece(bd, piece));
		FootPrint topFP = new FootPrint(bd.getUnit(tx, ty).getFP());
		//System.out.println("    Bd.unit(tx,ty).fp : \n" + bd.getUnit(tx, ty).getFP());
		FootPrint botFP = new FootPrint(movingPieceBd.getUnit(bx, by).getFP());
		//System.out.println("MvPcBd.unit(bx,by).fp : \n" + movingPieceBd.getUnit(tx, ty).getFP());
		return topFP.overlap(botFP);
	}
	private ArrayList<Pair<Integer,Integer>> extendDirsetToR3MS(Piece piece, Board bd)
	{	//Restricted-to-3 MoveSpace ; read if piece.center is false; optimisation is justified here
		ArrayList<Pair<Integer,Integer>> moves = new ArrayList<Pair<Integer,Integer>>(); 
		HashSet<Direction> dirSet = new HashSet<Direction>(piece.getDirSet()); //!!! VERY IMPORTANT : since MoveSpace is built inside the Piece constructor, not putting "new" here will .remove() the elements from the HashSet and render the Piece useless !! 
		Iterator<Direction> iter = dirSet.iterator();
		int startX = piece.getPos().x;
		int startY = piece.getPos().y;
		while (iter.hasNext()) 
		{
			int x = startX;
			int y = startY;
			Direction dir = iter.next();
			while (inRestrict3(startX,startY,x,y))
			{
				switch (dir)
				{ 	//go further in dir ; if you're still in a valid position, boundwise, add the move to the MvSp.
				case TL : x--; y--; if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case TM :      y--; if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case TR : x++; y--; if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case ML : x--;      if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case MR : x++;      if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case BL : x--; y++; if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case BM :      y++; if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case BR : x++; y++; if (inRestrict3(startX,startY,x,y) && Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				default : break;
				}
				if(Board.inBounds(x,y)) if (isOverlap(bd, piece, x, y)) break;
			}
			iter.remove();
		}	
		return moves;
	}
	private ArrayList<Pair<Integer,Integer>> extendDirsetToURMS(Piece piece, Board bd)
	{	//UnRestricted MoveSpace ; read if piece.center is true
		ArrayList<Pair<Integer,Integer>> moves = new ArrayList<Pair<Integer,Integer>>();
		HashSet<Direction> dirSet = new HashSet<Direction>(piece.getDirSet());
		for (int i = 0; i < dirSet.size(); i++)
		{	
			int x; int y;
			x = (int) piece.getPos().x;
			y = (int) piece.getPos().y;
			Direction dir = (Direction) dirSet.toArray()[i];
			while (Board.inBounds(x,y))
			{
				//System.out.println(x + "  " + y + "  " + inBounds(x,y) + " INBOUNDS");
				switch (dir)
				{
				case TL : x--; y--; if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case TM :      y--; if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case TR : x++; y--; if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case ML : x--;      if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case MR : x++;      if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case BL : x--; y++; if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case BM :      y++; if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				case BR : x++; y++; if (Board.inBounds(x,y)) moves.add(new Pair<Integer,Integer>(x,y)); break;
				default : break;
				}
				if(Board.inBounds(x,y)) if (isOverlap(bd, piece, x, y)) break;
			}
		}	
		return moves;
	}
	

	public ArrayList<Pair<Integer,Integer>> getArr()
	{
		return this.movesArr;
	}
	public boolean contains(Pair<Integer,Integer> pos)
	{
		for (Pair<Integer,Integer> allPos : this.movesArr)
		{
			if (pos.x.equals(allPos.x) && pos.y.equals(allPos.y)) return true;
		}
		return false;
	}
	public ArrayList<Pair<Integer,Integer>> extractDirMoves(Direction dir)
	{
		ArrayList<Pair<Integer,Integer>> dirMoves = new ArrayList<Pair<Integer,Integer>>();
		for (int i = 0; i < this.movesArr.size(); i++)
		{	
			Pair<Integer,Integer> dest = this.movesArr.get(i); 
			//moved is the translation vector for the movement
			Pair<Integer,Integer> moved = new Pair<Integer,Integer>(centralUnit.getPos().x - dest.x, centralUnit.getPos().y - dest.y);
			int dist = moved.x == 0 ? moved.y : moved.x;
			Pair<Integer,Integer> indic = new Pair<Integer,Integer>(moved.x/dist, moved.y/dist);
			switch (dir)
			{
			case TL: if (indic.equals(new Pair<Integer,Integer>(-1,-1))) dirMoves.add(dest);
				break;
			case TM: if (indic.equals(new Pair<Integer,Integer>( 0,-1))) dirMoves.add(dest);
				break;
			case TR: if (indic.equals(new Pair<Integer,Integer>( 1,-1))) dirMoves.add(dest);
				break;
			case ML: if (indic.equals(new Pair<Integer,Integer>(-1, 0))) dirMoves.add(dest);
				break;
			case MR: if (indic.equals(new Pair<Integer,Integer>( 1, 0))) dirMoves.add(dest);
				break;
			case BL: if (indic.equals(new Pair<Integer,Integer>(-1, 1))) dirMoves.add(dest);
				break;
			case BM: if (indic.equals(new Pair<Integer,Integer>( 0, 1))) dirMoves.add(dest);
				break;
			case BR: if (indic.equals(new Pair<Integer,Integer>( 1, 1))) dirMoves.add(dest);
				break;
			default: 
				break;
			}
		}
		return dirMoves;
	}
	
	
	
	public String toString() 
	{
		StringBuffer str = new StringBuffer("");
		for (int y=0;y<=17;y++)
		{
			for (int x=0;x<=17;x++)
			{
				//Pair<Integer,Integer> pos = new Pair<Integer,Integer>(x,y);
				boolean isValidMvPos = false;
				for (int i = 0 ; i < this.movesArr.size(); i++)
				{	
					if (this.movesArr.get(i).x == x && this.movesArr.get(i).y == y) isValidMvPos = true;
					if (isValidMvPos) {System.out.println(i +" (" + x + "," + y + ") " + this.movesArr.get(i));break;}
				}
				if (isValidMvPos) str.append("X");
				else str.append(".");
			}
			str.append("\n");
		}
		return str.toString();
	}
	public String toGameString()  
	{	//makes the board more understandable 
		StringBuffer str = new StringBuffer("y\\x| 0| 1| 2| 3| 4| 5| 6| 7| 8| 9|10|11|12|13|14|15|16|17|");
		for (int y=0;y<=17;y++) 
		{	
			//str.append("\n__________________________________________________________\n");
			str.append("\n---+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+\n");
			if (y<10) str.append("  "+y+"|");
			else 	  str.append(" " +y+"|");
			for (int x=0;x<=17;x++)
			{
				boolean isValidMvPos = false;
				for (int i = 0 ; i < this.movesArr.size(); i++)
				{	
					if (this.movesArr.get(i).x == x && this.movesArr.get(i).y == y) {isValidMvPos = true; break;}
				}
				if (isValidMvPos) str.append("XX|");
				else if (x == this.centralUnit.getPos().x && y == this.centralUnit.getPos().y) str.append("00|");
				else 			  str.append("  |");
			}
		}
		str.append("\n---+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+\n");
		return str.toString();
	}
}
