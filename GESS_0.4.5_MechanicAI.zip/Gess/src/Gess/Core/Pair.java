package Gess.Core;

public class Pair<S,T> {
	public final S x;
    public final T y;

    public Pair(S x, T y) 
    { 
        this.x = x;
        this.y = y;
    }
    public Pair(Pair<S,T> pair)
    {
    	this.x = pair.x;
    	this.y = pair.y;
    }
    
    public String toString() 
    {
    	return "(" + x.toString() + "," + y.toString() + ")";
    }
}

