package Gess.Core;

import static Gess.Core.Stone.B;
import static Gess.Core.Stone.E;
import static Gess.Core.Stone.O;
import static Gess.Core.Stone.W;
import static Gess.Core.Stone.mergeStone;

import java.util.ArrayList;
import java.util.Arrays;

public class FootPrint {

	private ArrayList<ArrayList<Stone>> fp = new ArrayList<ArrayList<Stone>>(); 
	private int black;
	private int white;
	private String fpStr;
	boolean isKing;
	
	/**
	 * Constructor
	 * @param unit
	 * @param bd
	 */
	public FootPrint (Unit unit, Board bd)
	{
		int x = unit.getPos().x;
		int y = unit.getPos().y;
		switch (unit.getNH()) 
		{
			
			case TLeC : 
				this.fp = stoneToArr(O,						O,						O,
									 O,						unit.getStone(),		bd.getStone(x+1,y  ),
									 O,						bd.getStone(x  ,y+1),	bd.getStone(x+1,y+1));
				break;
			
			case TMid : 
				this.fp = stoneToArr(O,						O,						O,
									 bd.getStone(x-1,y  ),	unit.getStone(),		bd.getStone(x+1,y  ),
									 bd.getStone(x-1,y+1),	bd.getStone(x  ,y+1),	bd.getStone(x+1,y+1));
				break;
			
			case TRiC : 
				this.fp = stoneToArr(O,						O,						O,
									 bd.getStone(x-1,y  ),	unit.getStone(),		O,
									 bd.getStone(x-1,y+1),	bd.getStone(x  ,y+1),	O);
				break;
			
			case MLeF : 
				this.fp = stoneToArr(O,						bd.getStone(x  ,y-1),	bd.getStone(x+1,y-1),
									 O,						unit.getStone(),		bd.getStone(x+1,y  ),
									 O,						bd.getStone(x  ,y+1),	bd.getStone(x+1,y+1));
				break;
			
				
			case Norm : 
				this.fp = stoneToArr(bd.getStone(x-1,y-1),	bd.getStone(x  ,y-1),	bd.getStone(x+1,y-1),
									 bd.getStone(x-1,y  ),	unit.getStone(),		bd.getStone(x+1,y  ),
									 bd.getStone(x-1,y+1),	bd.getStone(x  ,y+1),	bd.getStone(x+1,y+1));
				break;
				
			case MRiF : 
				this.fp = stoneToArr(bd.getStone(x-1,y-1),	bd.getStone(x  ,y-1),	O,
									 bd.getStone(x-1,y  ),	unit.getStone(),		O,
									 bd.getStone(x-1,y+1),	bd.getStone(x  ,y+1),	O);
				break;
				
			case BLeC : 
				this.fp = stoneToArr(O,						bd.getStone(x  ,y-1),	bd.getStone(x+1,y-1),
									 O,						unit.getStone(),		bd.getStone(x+1,y  ),
									 O,						O,						O);
				break;
				
			case BMid : 
				this.fp = stoneToArr(bd.getStone(x-1,y-1),	bd.getStone(x  ,y-1),	bd.getStone(x+1,y-1),
									 bd.getStone(x-1,y  ),	unit.getStone(),		bd.getStone(x+1,y  ),
									 O,						O,						O);
				break;
				
			case BRiC : 
				this.fp = stoneToArr(bd.getStone(x-1,y-1),	bd.getStone(x  ,y-1),	O,
									 bd.getStone(x-1,y  ),	unit.getStone(),		O,
									 O,						O,						O);
				break;
				
			default : break;		
		}
		this.fpStr = this.toString();
	}
	public FootPrint (String str)
	{
		//Uses letters B, W, E, used in defining kings.
		this.fpStr = str;
		String[] tokens = str.split(" ");
		ArrayList<ArrayList<Stone>> fp = new ArrayList<ArrayList<Stone>>();
		for (int y=0; y<=2; y++)
		{
			ArrayList<Stone> row = new ArrayList<Stone>(); 
			for	(int x=0; x<=2; x++)
			{
				char c = tokens[y].charAt(x);
				switch (c) 
				{
					case 'B' : row.add(B);break;
					case 'W' : row.add(W);break;
					case 'E' : row.add(E);break;
					case 'O' : row.add(O);break;
					default  : break;
					
				}
			}
			fp.add(row);
		}
		this.fp = fp;
	}
	public FootPrint (FootPrint fp)
	{
		this.fpStr = new String(fp.fpStr);
		ArrayList<ArrayList<Stone>> newFP = new ArrayList<ArrayList<Stone>>();
		for (int y = 0; y <= 2; y++)
		{
			ArrayList<Stone> row = new ArrayList<Stone>();
			for (int x = 0; x <= 2; x++)
			{
				row.add(fp.getStone(x, y));
			}
			newFP.add(row);
		}
		this.fp = newFP;
		this.setCount();
	}
	/**
	 * A subfunction of the second constructor, to make things understandable
	 * @param tl : top left
	 * @param tm : top middle
	 * @param tr : top right
	 * @param ml : middle left, etc
	 * @param mm
	 * @param mr
	 * @param bl
	 * @param bm
	 * @param br
	 * @return a 3*3 matrix of stones
	 */
	private ArrayList<ArrayList<Stone>> stoneToArr(Stone tl, Stone tm, Stone tr, Stone ml, Stone mm, Stone mr, Stone bl, Stone bm, Stone br)
	{
		ArrayList<Stone> top = new ArrayList<Stone>(Arrays.asList(tl, tm, tr));
		ArrayList<Stone> mid = new ArrayList<Stone>(Arrays.asList(ml, mm, mr));
		ArrayList<Stone> bot = new ArrayList<Stone>(Arrays.asList(bl, bm, br));
		ArrayList<ArrayList<Stone>> fp = 
					new ArrayList<ArrayList<Stone>>(Arrays.asList(top,mid,bot));
		return fp;
		
	}
	private void setCount()
	{
		int white=0;
		int black=0;
		for(int y=0; y<=2; y++)
		for(int x=0; x<=2; x++)
		{
			switch (this.fp.get(y).get(x))
			{
			case B : black++; break;
			case W : white++; break;
			default : break;
			}
		}
		this.white = white;
		this.black = black;
	}
	
	
	public static FootPrint merge(Stone stone, FootPrint top, FootPrint bot)
	{	//The player's stone must be known to decide who eats whom
		StringBuffer strFp = new StringBuffer("");
		for (int y=0; y<=2; y++)
		{
			for (int x=0; x<=2; x++) 
			{
				switch (stone) {
				case B: case W: strFp.append(mergeStone(stone, top.getStone(x,y), bot.getStone(x,y)).toString()); break;
				default : strFp.append("I"); break;
				}
			}
			strFp.append(" ");
		}
		if (strFp.toString().contains("I")) System.out.println("Inexistant stone error in FootPrint merge \n" + strFp);
		return new FootPrint(strFp.toString());
	}

	
	public boolean isKing(Stone stone)
	{	//comparison through ArrayList<ArrayList<Stone>> because .equals on FootPrint is always false and I don't see why
		if      (stone.equals(Stone.B)) return this.fpStr.equals("BBB BEB BBB");
		else if (stone.equals(Stone.W)) return this.fpStr.equals("WWW WEW WWW");
		else 
		{
			System.out.println("Error in isKing");
			return false;
		}
	}
	/**
	 * This function can be subject to change, as conflicting rules for what makes a piece in Gess exist
	 *
	 * GO RULE
	 * One rule is that neighborHood must be Norm, written below as if(fpStone.equals(Stone.O)) return false
	 * This rule implies that you have to "rescue" border pieces with other pieces.
	 * 
	 * CHESS RULE
	 * Another rule, which would ask a reworking of the board structure and the neighborHood enumerator
	 * is that you can consider the line of out-of-bounds stones as possible centers for pieces, to get
	 * the lonely stones away from the border if necessary
	 * 
	 * MID RULE
	 * Without the first rule, our code works well as an in between : you can move any piece the center 
	 * of which is on the Board
	 * 
	 * CURRENT : MID RULE
	 * 
	 * @param stone
	 * @return if the footprint corresponds to a playable piece
	 */
	public boolean isPiece(Stone stone)
	{
		//We need to have at least 1 stone of the player's color, and 
		//NO stone of the enemy color in a FootPrint to make a piece
		boolean isPiece = false;
		for (int y=0; y<=2; y++)
		for (int x=0; x<=2; x++) 
		{
			Stone fpStone = this.getStone(x,y);
			if (fpStone.equals(stone) && !(x==1 && y==1)) isPiece = true; //at least 1 ally that's not just the center 
			else if (fpStone.equals(stone.getOpp())) // || fpStone.equals(Stone.O)) //no enemy & NH is !Norm 
			{
				//System.out.println("Found opposite stones in footprint");
				return false; 
			}
		}
		return isPiece;
	}
	public boolean overlap(FootPrint otherFp)
	{
		//checks for any overlap
		for (int y=0; y<=2; y++)
		for (int x=0; x<=2; x++) 
		{
			//System.out.println("Top stone : " + this.getStone(x,y) + "  Bot stone : " + otherFp.getStone(x,y) + "  " + x + "," +y);
			boolean isPlayerStone =    this.getStone(x,y).equals(B) ||    this.getStone(x,y).equals(W); 
			boolean isOtherPStone = otherFp.getStone(x,y).equals(B) || otherFp.getStone(x,y).equals(W); 
			if (isPlayerStone && isOtherPStone) return true ;
		}
		return false;
	}	
	public Stone getStone(int x, int y)
	{
		return this.fp.get(y).get(x);
	}
	public int getCount(Stone stone)
	{
		return stone.equals(B) ? black : white;
	}
	public ArrayList<ArrayList<Stone>> getArr()
	{
		return this.fp;
	}
	
	public String toString()
	{
		StringBuffer str = new StringBuffer("");
		for (int y=0; y<=2; y++)
		{
			for(int x=0; x<=2; x++) 
			{
				char c = 'e'; //for "error"
				Stone stone = this.fp.get(y).get(x);
				switch (stone) 
				{
					case E : c = 'E'; break;
					case W : c = 'W'; break;
					case B : c = 'B'; break;
					case O : c = 'O'; break;
					default : break;
				}
				str.append(c);
			}
			if (y != 2) str.append(" ");
		}
		return str.toString();
	}
}
