package Gess.Core;

 
//TODO : maybe put part 4 earlier ? Analyze the overall protocol to see if it works


import java.util.ArrayList;
import java.util.Random;

public class AIPlayer extends Player {
	
	/**
	 * Health constants //it seems this actually slows down the software compared to hardcoded values... 
	 */
	
	public static final int CHECKMATE = 2000;
	public static final int KINGSWGHT = 50;
	public static final int STONEWGHT = 10;
	public static final int LASKINGCH = 30;
	public static final int ANYKINGCH = 20;
	public static final int MAXWAIT   = 5;
	
	public final Stone stone;
	private ArrayList<Unit> unitList; //all possible pieces
	private ArrayList<Move> moveList; //all possible moves
	
	
	/**
	 * List center squares of all playable pieces as Units
	 * @param game
	 */
	private static ArrayList<Unit> listUnits (Board bd, Stone stone)
	{
		ArrayList<Unit> unitList = new ArrayList<Unit>();
		for (int y = 0; y <= 17; y++)
		for (int x = 0; x <= 17; x++)
		{
			Unit unit = bd.getUnit(x,y); 
			if (unit.getFP().isPiece(stone)) unitList.add(unit);
		}
		//System.out.println(unitList);
		return unitList;
	}
	private static ArrayList<Move> listMoves (Board bd, Stone stone, ArrayList<Unit> unitList)
	{
		ArrayList<Move> moveList = new ArrayList<Move>(); 
		for (int i = 0; i < unitList.size(); i++)
		{
			Piece piece = new Piece(unitList.get(i), stone, bd);
			ArrayList<Pair<Integer,Integer>> movesArr = piece.getMvSp().getArr();
			for (int j = 0; j < movesArr.size(); j++)
			{
				//System.out.println("j = " + j + "   ;   piece at : " + piece.getPos() + "   ;   movesArr[j] = " + movesArr.get(j));
				Unit dest = bd.getUnit(movesArr.get(j).x, movesArr.get(j).y);
				Move move = new Move(bd,piece,dest);
				moveList.add(move); //don't forget to computeHealth for all, sometime later
			}
		}
		return moveList;
	}
	private static ArrayList<Move> listMoves (Board bd, Stone stone)
	{
		return listMoves(bd, stone, listUnits(bd,stone));
	}

	/**
	 * Constructor
	 * @param stone
	 */
	public AIPlayer(Stone stone)
	{
		this.stone = stone;
	}
	
	private void update(Game game)
	{
		this.unitList = listUnits(game.getCurrentBd(),this.stone);
		this.moveList = listMoves(game.getCurrentBd(),this.stone, this.unitList);
	}

	private Move selectRandZeroMove(ArrayList<Move> zeroHealthList, Game game) throws NullPointerException
	{
		Random rand = new Random();
		Move move = new Move();
		for (int i=0; i < 1; i++)
		{
			int r = rand.nextInt(zeroHealthList.size());
			move = zeroHealthList.get(r);
			if (!move.isValid(game)) {zeroHealthList.remove(r); i--;} 
		}
		return move;
	}
	private Move selectCheckmateOrBestMove(Game game)
	{
		Board currntBd = game.getCurrentBd();
		Stone enemy = this.getStone().getOpp();
		Move move;
		int ownCurrRings = currntBd.getKingNb(stone);
		int oppCurrRings = currntBd.getKingNb(enemy);
		
		//Part 1 : checking for a Checkmate or a kingSlay/kingMake ; clean bad king-related moves from moveList 
		System.out.println("\nPart 1");
		System.out.println("I have " + ownCurrRings + " kings and my opponent has " + oppCurrRings);
		Move kingSlayOrMake = null;
		
		ArrayList<Move> positiveMoves = new ArrayList<Move>();
		ArrayList<Move> negativeMoves = new ArrayList<Move>();
		
		for (int i = 0; i < moveList.size(); i++)
		{
			move = moveList.get(i);
			Board futureBd = move.getFutureBd(); 
			int ownFutuRings = futureBd.getKingNb(stone);
			int oppFutuRings = futureBd.getKingNb(enemy);
			int bonus = computeHealthKings(ownCurrRings, ownFutuRings, oppCurrRings, oppFutuRings); 
			if (bonus == CHECKMATE) 
			{
				System.out.println("Found checkmate for move " + move);
				if (move.isValid(game)) return move;
				else {System.out.println("But it wasn't valid !"); moveList.remove(i);}
			}
			if (bonus <= -KINGSWGHT) 
			{
				negativeMoves.add(move);
				moveList.remove(i); 
				i--; 
				continue;
			}

			move.addHealth(bonus);
			
			try 
			{
				if (bonus > kingSlayOrMake.getHealth() && move.isValid(game)) 
				{
					kingSlayOrMake = move ;
					System.out.println("Better kingSlayOrMake with "+ bonus +" health found.");
				}
			} 
			catch (NullPointerException e)
			{
				if (bonus > 0) System.out.println("First kingSlayOrMake, with "+ bonus + " health found.");
				if (bonus >= KINGSWGHT && move.isValid(game)) 
				{
					kingSlayOrMake = move;
					System.out.println("Found a valid way to kill or make a king for move " + move);
				}
			}
		}
		if (!(kingSlayOrMake ==  null)) {System.out.println("Returning kingSlayOrMake : " + kingSlayOrMake);return kingSlayOrMake;}
		
	
		//Part 2 : Checking stone count ; more cleaning of moveList
		System.out.println("\nPart 2");
		ArrayList<Move> currEnemyMoves = listMoves(currntBd,enemy);
		int currOwnKingsThreatened = countCheckAmount(currEnemyMoves, enemy, ownCurrRings);
		int currOppKingsThreatened = countCheckAmount(moveList, stone, oppCurrRings);
		
		for (int i = 0; i < moveList.size();i++)
		{
			move = moveList.get(i);
			int bonus = computeHealthStones(move);
			move.addHealth(bonus);
			if (bonus < 0) {negativeMoves.add(move); moveList.remove(i); i--; continue;} //at this point, there are no negative moves in moveList, so no need to move.addHealth
			if (bonus > 0) {positiveMoves.add(move); moveList.remove(i); i--; continue;}
		}
		if (!positiveMoves.isEmpty())
		{
			for (int i = 0; i < positiveMoves.size(); i++)
			{
				move = positiveMoves.get(i);
				System.out.println("Checking if a positive move " + move + " puts the enemy in Check or causes SelfCheck. Move " + (i+1) + " of " + positiveMoves.size());
				Board futureBd = move.getFutureBd();
				int ownFutuRings = futureBd.getKingNb(stone);
				int oppFutuRings = futureBd.getKingNb(enemy);
				
				ArrayList<Move> futuEnemyMoves = listMoves(futureBd,enemy);
				ArrayList<Move> futuPlayrMoves = listMoves(futureBd,stone);
				int futuOwnKingsThreatened = countCheckAmount(futuEnemyMoves, enemy, ownCurrRings);
				int futuOppKingsThreatened = countCheckAmount(futuPlayrMoves, stone, oppCurrRings);
				int extraDanger = futuOwnKingsThreatened - currOwnKingsThreatened;
				int extraAttack = futuOppKingsThreatened - currOppKingsThreatened;
				
				
				if (futuOwnKingsThreatened == ownFutuRings) {negativeMoves.add(move); positiveMoves.remove(i); 	i--; continue;}
				if (futuOppKingsThreatened == oppFutuRings)  move.addHealth(			 LASKINGCH);
				if (extraDanger > 0) 						 move.addHealth(-extraDanger*ANYKINGCH);
				if (extraAttack > 0) 						 move.addHealth( extraAttack*ANYKINGCH);
				
				System.out.println("Move " + move + " has " + move.getHealth() + " health.");
				
				if (move.getHealth() < 0) {negativeMoves.add(positiveMoves.get(i)); positiveMoves.remove(i); i--;}
			}
			if (!positiveMoves.isEmpty())
			{	
				try 
				{
					move = getBestMove(positiveMoves, game);
					return move;
				}
				catch (IllegalArgumentException e) 
				{
					System.out.println("Elements of the list PositiveMoves were all invalid or uninteresting (check).");
				}
			}
		}
		else System.out.println("No positive moves stone-wise.");
		
		//Part 3 : only moves with (health==0) left ; just return the first one that doesn't SelfCheck, with a max wait time of 10 tries
		System.out.println("\nPart 3");
		ArrayList<Move> zeroHealthList = this.moveList;
		int wait = 0;
		while (wait < MAXWAIT) {
			move = selectRandZeroMove(zeroHealthList, game);
			System.out.println("Checking if a random leftover move " + move + " puts the enemy in Check or causes SelfCheck. Move " + (wait+1) + " of max wait time = " + MAXWAIT);
			Board futureBd = move.getFutureBd();
			int ownFutuRings = futureBd.getKingNb(stone);
			int oppFutuRings = futureBd.getKingNb(enemy);
			
			ArrayList<Move> futuEnemyMoves = listMoves(futureBd,enemy);
			ArrayList<Move> futuPlayrMoves = listMoves(futureBd,stone);
			int futuOwnKingsThreatened = countCheckAmount(futuEnemyMoves, enemy, ownCurrRings);
			int futuOppKingsThreatened = countCheckAmount(futuPlayrMoves, stone, oppCurrRings);
			int extraDanger = futuOwnKingsThreatened - currOwnKingsThreatened;
			int extraAttack = futuOppKingsThreatened - currOppKingsThreatened;
			
			
			if (futuOwnKingsThreatened == ownFutuRings) {wait++; continue;}
			if (futuOppKingsThreatened == oppFutuRings)  move.addHealth(			 LASKINGCH);
			if (extraDanger > 0) 						 move.addHealth(-extraDanger*ANYKINGCH);
			if (extraAttack > 0) 						 move.addHealth( extraAttack*ANYKINGCH);
			
			
			if (move.getHealth() >= 0) return move; //can't change moveList and negativeMoves without knowing the index
			else System.out.println("Move was uninteresting, health = " + move.getHealth());
			wait++;
		}
		
		
		//Part 4 : the logical conclusion here, since no random move works, is that I am in "full" check ; 
		//however, it may be a check that only happens if the last enemy king separates itself, which is a rare case : 
		//we take care of that by checking the validity of the enemyKillingMove in the findEnemyKillingMove function 
		//Also, we suppose here that a full check move can only happen one move at a time, which isn't necessarily the case, 
		//but if there are many possibilities for full check, then AIPlayer was necessarily in checkmate anyways !
		//Finally, since we already checked for moves that could eat a threat and remove check in Part 2, 
		//we only need to check for moves that avoid or block
		System.out.println("\nPart 4\nI am probably in full check. Verifying.");
		try 
		{
			Move enemysKillingMove = null;
			try
			{
				enemysKillingMove = AIPlayer.findKillingMove(currEnemyMoves, enemy, game.getPreviousBd());
				System.out.println("Found enemy check move : " + enemysKillingMove.toString()); //this is the part that would throw the exception, the toString is necessary for the exception to happen.
			}
			catch (NullPointerException e)
			{
				System.out.println("Actually no enemy check found when initializing part 4, probably because only breaking the last king can kill me.");
				System.out.println("Going directly to Random Move. Human reader : ignore following \"unexpected error in Part 4\" message.");
			}
			Unit initPos = enemysKillingMove.getChosenPiece().getUnit();
			Unit killPos = enemysKillingMove.getChosenDest();
			
			for (int i = 0; i < moveList.size() + negativeMoves.size(); i++)
			{	//here the AI tries each of its zero valued moves to try and find one that cancels the full check
				//First pick a move, then check if I am still in check after the move by trying to find a killing move in the futuBd
				if (i < moveList.size())
				{
					move = moveList.get(i);
					if (!move.isValid(game)) { moveList.remove(i); i--; continue;}
				}
				else
				{
					move = negativeMoves.get(i - moveList.size());
					if (!move.isValid(game)) { negativeMoves.remove(i - moveList.size()); i--; continue;}
				}
				System.out.println("Trying move : " + move + " which is number " + i + " of " + (moveList.size()+negativeMoves.size()));
				Board futuBd = move.getFutureBd();
				try 
				{
					Piece updatedKillerPiece = null;
					try 
					{
						updatedKillerPiece = new Piece(initPos,enemy,futuBd); //if AI enacts his move, the enemy's piece MvSp must be checked for changes
					}
					catch (IllegalArgumentException e)
					{
						System.out.println("Killer piece not updateable.");
						ArrayList<Move> futuEnemyMoves = listMoves(futuBd, enemy);
						Move fullCheck = AIPlayer.findKillingMove(futuEnemyMoves, enemy, currntBd);
						if (fullCheck == null) 
						{
							System.out.println("No killing move found after " + move); 
							return move;
						}
						else 
						{
							System.out.println("But I am still in fullCheck because of enemy move : " + fullCheck);
							continue; 
						}
					}
					
					if (!updatedKillerPiece.getMvSp().contains(killPos.getPos()))
					{	//if killPos isn't in the MoveSpace anymore, check if this got me out of fullcheck
						//putting this verif° here will probably favor moves that hide the king and block enemy advances, it might be the most effective solution to keep enemies away... or just a useless sacrifice.
						System.out.println("KillPos not in enemy KillerPiece's MvSp anymore.");
						ArrayList<Move> futuEnemyMoves = listMoves(futuBd, enemy);
						Move fullCheck = AIPlayer.findKillingMove(futuEnemyMoves, enemy, currntBd);
						if (fullCheck == null) 
						{
							System.out.println("No killing move found after " + move); 
							return move;
						}
						else 
						{
							System.out.println("But I am still in fullCheck because of enemy move : " + fullCheck);
							continue; //continue cuz the move didn't get us out of fullcheck
						}
					}
					
					//at this point we've made sure that killPos is still in uKP.MvSp
					Move updatedEKM = null;
					try 
					{
						updatedEKM = new Move(futuBd,updatedKillerPiece,killPos);
					}
					catch (IllegalArgumentException e)
					{
						System.out.println("The enemy's killing move could not be rebuilt in a directly threatening way.");
						ArrayList<Move> futuEnemyMoves = listMoves(futuBd, enemy);
						Move fullCheck = AIPlayer.findKillingMove(futuEnemyMoves, enemy, currntBd);
						if (fullCheck == null)
						{
							System.out.println("No other killing move found after " + move);
							return move;
						}
						else
						{
							System.out.println("But I am still in fullCheck because of enemy move : " + fullCheck);
							continue;
						}
					}
									
					if (!updatedEKM.isValid(enemy,currntBd))
					{
						System.out.println("The enemy's threat is now invalid.");
						ArrayList<Move> futuEnemyMoves = listMoves(futuBd, enemy);
						Move fullCheck = AIPlayer.findKillingMove(futuEnemyMoves, enemy, currntBd);
						if (fullCheck == null)
						{
							System.out.println("No killing move found after " + move);
							return move;
						}
						else
						{
							System.out.println("But I am still in fullCheck because of enemy move : " + fullCheck);
							continue;
						}
					}
					
					if (!isFullCheck(updatedEKM, enemy)) 
					{	//
						System.out.println("The enemy's studied killing move does not cause fullCheck anymore.");
						ArrayList<Move> futuEnemyMoves = listMoves(futuBd, enemy);
						Move fullCheck = AIPlayer.findKillingMove(futuEnemyMoves, enemy, currntBd);
						if (fullCheck == null)
						{
							System.out.println("No killing move found after " + move);
							return move;
						}
						else
						{
							System.out.println("But I am still in fullCheck because of enemy move : " + fullCheck);
							continue;
						}
					}
				}
				catch (Exception e)
				{	//if the move has made the piece unplayable, it's probably good
					System.out.println(e +"\nAn unexpected exception has happened at part 4 for move : " + move);
					return move;
				}
				
			}
			/*
			Unit killPos = enemysKillingMove.getChosenDest();
			Piece killerPiece = enemysKillingMove.getChosenPiece();
			Unit initPos = killerPiece.getUnit();
			Direction killDir = Direction.getDir(initPos, killPos);
			ArrayList<Pair<Integer,Integer>> currKillLine = killerPiece.getMvSp().extractDirMoves(killDir);
			for (int i = 0; i < this.moveList.size(); i++)
			{
				move = this.moveList.get(i);
				Piece futuKillerPiece = new Piece(initPos,enemy,move.getFutureBd());
				ArrayList<Pair<Integer,Integer>> futuKillLine = futuKillerPiece.getMvSp().extractDirMoves(killDir);
				boolean
				if (futuKillLine.size() < currKillLine.size() && move.isValid(game))
			}*/
		}
		catch (Exception e)
		{
			System.out.println(e + "\nAn unexpected problem has happened in Part 4.");
		}
		
		
		//Part 5 : all has failed, must play
		
		System.out.println("\nPart 5\nNo more time. No positive move found. Selecting random valid move.");
		try 
		{
			return selectRandZeroMove(zeroHealthList, game);
		}
		catch (NullPointerException e)
		{
			System.out.println("No valid random zero-health move ; trying a negative move...");
			try 
			{
				return getBestMove(negativeMoves, game);
			}
			catch (IllegalArgumentException f)
			{
				System.out.println("No valid move found. Deadlock.");
				return new Move();
			}
		}
	}
	
	/**
	 * Checks evolution in number of kings and rewards/punishes appropriately
	 * @param game
	 * @param move
	 * @return
	 */
	private static int computeHealthKings(int oldPlayrRings, int newPlayrRings, int oldEnemyRings, int newEnemyRings)
	{
		int bonus = 0;
		if (newPlayrRings == 0) 		   return  -CHECKMATE; //Easier to check against suicide here, where it costs less than Move.isValid
		if (newEnemyRings == 0)		   	   return   CHECKMATE; //Winning move
		int kingsGained = newPlayrRings - oldPlayrRings;
		int kingsKilled = newEnemyRings - oldEnemyRings;
		if (kingsGained > 0) bonus += KINGSWGHT*kingsGained; //We craft new Kings/Rings
		if (kingsGained < 0) bonus += KINGSWGHT*kingsGained; //We destroy our own Ring(s), + because kingsGained can be negative
		if (kingsKilled > 0) bonus += KINGSWGHT*kingsKilled; //We destroy an/some enemy Ring(s)
		return bonus;
	}
	/**
	 * Count how much enemies are eaten vs self eating
	 * @param currntBd
	 * @param futureBd
	 * @param move
	 * @return bonus
	 */
	private static int computeHealthStones(Move move)
	{	
		int bonus = 0; 
		//losses should always be positive in this context, so that bonus is appropriate 
		bonus -= move.getOwnLoss()*STONEWGHT;
		bonus += move.getOppLoss()*STONEWGHT;
		return bonus;
	}
	/**
	 * From stone's POV : returns max amount of enemy kings in check for a single move ; tests every move
	 * @param moveList stone's moveList
	 * @param stone 
	 * @param enemyKings stoneOpp's number of kings
	 * @return nbEnemiesInCheck ; highest number of kills of all given moves, generally 0 or 1
	 */
	private static int countCheckAmount(ArrayList<Move> moveList, Stone stone, int currntEnemyKings)
	{	
		Stone enemy = stone.getOpp();
		int enemiesInCheck = 0; 
		for(int i=0; i<moveList.size(); i++)
		{ 	
			int futureEnemyKings = moveList.get(i).getFutureBd().getKingNb(enemy);
			int kingsKilled = currntEnemyKings - futureEnemyKings;
			if (kingsKilled > enemiesInCheck) enemiesInCheck = kingsKilled;
		}
		return enemiesInCheck;
	}
	/**
	 * A function that verifies if a move wins the game
	 * @param move move to verify if it is a full check/checkmate
	 * @param stone "stone" is the player doing "move"
	 * @param game
	 * @return 
	 */
	private static boolean isFullCheck(Move move, Stone stone)
	{
		return move.getFutureBd().getKingNb(stone.getOpp()) == 0;
	}
	private static Move findKillingMove(ArrayList<Move> currEnemyMoves, Stone enemy, Board previousBd)
	{
		for (int i = 0; i < currEnemyMoves.size(); i++)
		{
			Move enemyMove = currEnemyMoves.get(i);
			if (isFullCheck(enemyMove, enemy) && enemyMove.isValid(enemy, previousBd)) return enemyMove;
		}
		return null;
	}
	
	/**
	 * Checks for a mate first
	 */
	public void playTurn(Game game)
	{
		System.out.println(game.getCurrentBd().toGameString());
		System.out.println("It is " + this.stone +"'s turn.");
		System.out.println("COMPUTING MOVE");
		
		this.update(game);
		Move move = selectCheckmateOrBestMove(game);
		
		System.out.println("AI player " + this.stone + "'s move is : " + move);
		System.out.println(move.toFPString());
		System.out.println("Own loss : "   + move.getOwnLoss() + " stones\n" + 
						   "Enemy loss : " + move.getOppLoss() + " stones");
		
		if (move.equals(new Move())) System.out.println("NO VALID MOVE FOUND ERROR.");
		game.update(move.getFutureBd());
	}
	
		
	public Stone getStone()
	{
		return this.stone;
	}
	public static Move getBestMove(ArrayList<Move> moveList, Game game) throws IllegalArgumentException
	{
		int i = 0;
		Move move = new Move();
		while (!move.isValid(game) || move.hasChosenDest() == false)
		{
			if(i == moveList.size()) throw new IllegalArgumentException();
			move = moveList.get(i);
			i++;
		}
		
		int max = move.getHealth();
		for (; i < moveList.size(); i++)
		{
			if (moveList.get(i).getHealth() > max)
			{
				move = moveList.get(i);
				max = move.getHealth();
			}
		}
		return move;
	}
}


