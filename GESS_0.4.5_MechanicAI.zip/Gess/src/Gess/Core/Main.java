package Gess.Core;


import Gess.Core.Game.PlayerType;
import javafx.application.Application;

public class Main { //extends Application {
	/*
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}*/
	
	public static void main (String args[]) 
	{
		Game game = new Game();
		/*
		Game game = new Game(new String[] 
			   {"EEEEEEWWEEEEEEEEEE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEEWWWEEEEEEEEEE",
					   "EEEEWWEWEEEEEEEEEE",
					   "EEEEWWWWWWEEEEEEEE",
					   "EEEEBEBWEEEEEEEEEE",
					   "EEEEBBEEEEEEEEEEEE",
					   "EEEEBEEEEEEEEEEEWE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEBBEEEEEEEEEEEE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEEEEEEEEEEEEEEE",
					   "EEEEEEEEEBBBEEEEEE",
					   "EEEEEEEEEBEBEEEEEE",
					   "EEEEEEEEEBBBBEEEEE"},
			   Stone.W);
		*/
		game.play(PlayerType.AI,PlayerType.AI);
	}
	
}
