package Gess.Core;

public class Move {
	
	
	private Piece chosenPiece;
	private boolean hasChosenPiece;
	private Unit chosenDest;
	private boolean hasChosenDest;
	private boolean confirmMove; 
	private Board futureBd;
	private int health; //health is the quality of a move, how much pieces you lose etc. 
	public static final int SCOPE = 200; //health € [-SCOPE;SCOPE]
	private int ownLoss; //stoneCount change for Stone at the end of the move 
	private int oppLoss; //stoneCount change for Stone.opp at the end of the move
	
	private FootPrint botFPtest; //for println 
	
	
	/**
	 * Constructor for an empty move that is filled in element by element by a human
	 */
	public Move() 
	{
		this.hasChosenPiece = false;
		this.chosenPiece = null;
		
		this.hasChosenDest = false;
		this.chosenDest = null;
		
		this.confirmMove = false;
		
		this.futureBd = null;	
		this.health = 0;
	}
	/**
	 * Constructor for a move used by AI, is done automatically in a loop
	 * @param game
	 * @param piece
	 * @param dest
	 */
	public Move(Board bd, Piece piece, Unit dest) throws IllegalArgumentException
	{	
		if (!piece.getMvSp().contains(dest.getPos())) throw new IllegalArgumentException("Invalid piece/dest combo in Move constructor");
		this.chosenPiece = piece;
		this.hasChosenPiece = true;
		
		this.chosenDest = dest;
		this.hasChosenDest = true;
		
		this.buildFutureBd(piece.getStone(), bd);
		this.health = 0;
	}
	public void buildFutureBd (Stone stone, Board startBd)
	{
		this.futureBd = new Board(bdAfterMove(stone, startBd));
	}

	
	/**
	 * Methods for a human's progressive construction of Move
	 */
	public void selectPiece(Game game, Unit unit) throws IllegalArgumentException
	{
		//if this isn't a valid piece of player "game.getStone", throw exception, we shouldn't be able to use this
		if (!unit.getFP().isPiece(game.getStone())) throw new IllegalArgumentException("Not a valid piece in Move constructor\n");
		else {
			this.chosenPiece = new Piece(unit,game.getStone(),game.getCurrentBd()); //TODO new ? 
			this.hasChosenPiece = true;
		}
	}
	public void deselectPiece()
	{
		this.chosenPiece = null;
		this.hasChosenPiece = false;
	}	
	public void selectDest (Game game, int x, int y) throws IllegalArgumentException
	{
		this.chosenDest = game.getCurrentBd().getUnit(x, y);
		this.hasChosenDest = true;
	}
	public void deselectDest()
	{
		this.chosenDest = null;
		this.hasChosenDest = false;
	}
	public void confirmMove()
	{
		this.confirmMove = true;
	}
	
	/**
	 * The main computation we want to make with the Move class
	 * @param stone
	 * @param startBd
	 * @return
	 */
	public Board bdAfterMove(Stone stone, Board startBd)
	{
		Board endBd = new Board(Board.bdWOpiece(startBd, chosenPiece));
		FootPrint topFP = new FootPrint(chosenPiece.getUnit().getFP());
		FootPrint botFP = new FootPrint(endBd.getUnit(chosenDest.getPos().x,chosenDest.getPos().y).getFP());
		this.botFPtest = botFP;
		FootPrint mergedFP = new FootPrint(FootPrint.merge(stone, topFP, botFP));
		this.ownLoss = botFP.getCount(stone) + topFP.getCount(stone) - mergedFP.getCount(stone); //positive number
		this.oppLoss = botFP.getCount(stone.getOpp()) - mergedFP.getCount(stone.getOpp()); //positive number
		endBd.setPieceAt(mergedFP, chosenDest.getPos().x, chosenDest.getPos().y);
		return endBd;
	}
	
	/**
	 * Returns if the selection of a new position for a given piece is a valid move
	 * Pretty computation hungry
	 * @param bd		the full board on which a piece is moving
	 * @param piece		the moved piece
	 * @param move		
	 * @return
	 */
	public boolean isValid(Game game)
	{	//no passing is taken care of by how a MoveSpace does not accept the same spot as valid 
		//the rest of the function consists i checking if the new board is different from the old board 
		//no killing your own last king
		//works for any move on a given board, no matter the player actually playing
		
		if (this.hasChosenDest == false) return false;
		Board lastTurnBd = game.getPreviousBd();
		Board bdAfterMove = this.futureBd;
		boolean noSuicide = bdAfterMove.getKingNb(this.getChosenPiece().getStone()) > 0;
		boolean noKoLoop = !bdAfterMove.equals(lastTurnBd); //might be hungry, maybe convert to string and compare strings?
		boolean destInMvSp = this.getChosenPiece().getMvSp().contains(this.getChosenDest().getPos());
		return noSuicide && noKoLoop && destInMvSp;
	}
	public boolean isValid(Stone stone, Board previousBd) 
	{	
		if (!this.getChosenPiece().getStone().equals(stone)) return false; //make sure you're applying the method to an appropriate move for the appropriate player
		if (this.hasChosenDest == false) return false;
		Board lastTurnBd = previousBd;
		Board bdAfterMove = this.futureBd;
		boolean noSuicide = bdAfterMove.getKingNb(stone) > 0;
		boolean noKoLoop = !bdAfterMove.equals(lastTurnBd); //might be hungry, maybe convert to string and compare strings?
		boolean destInMvSp = this.getChosenPiece().getMvSp().contains(this.getChosenDest().getPos());
		return noSuicide && noKoLoop && destInMvSp;
	}
	
	public boolean hasChosenPiece()
	{
		return this.hasChosenPiece;
	}
	public boolean hasChosenDest()
	{
		return this.hasChosenDest;
	}
	public boolean hasConfirmedMove() 
	{
		return this.confirmMove;
	}
	
	public Board getFutureBd()
	{
		return this.futureBd;
	}
	public void nullFutureBd()
	{
		this.futureBd = null;
	}
	public Piece getChosenPiece()
	{
		return this.chosenPiece;
	}
	public Unit getChosenDest() 
	{
		return this.chosenDest;
	}
	
	public int getHealth()
	{
		return this.health;
	}
	public int getOwnLoss()
	{
		return this.ownLoss;
	}
	public int getOppLoss()
	{
		return this.oppLoss;
	}
	public void addHealth(int bonus)
	{
		this.health += bonus;
		if (this.health > SCOPE) this.health = SCOPE; 
		if (this.health < -SCOPE) this.health = -SCOPE;
	}

	
	public String toString()
	{
		return "[[ " + this.chosenPiece.getUnit().toString() + " --> " + this.getChosenDest().toString() + " ]]";
	}
	public String toFPString()
	{
		String str = ("Top :\n" + this.chosenPiece.getUnit().getFP().toString() +
					"\nBot :\n" + this.botFPtest + //this.futureBd.getUnit(this.chosenDest.getPos().x,this.chosenDest.getPos().x).getFP().toString() +
					"\nResult :\n" + this.getFutureBd().getUnit(this.chosenDest.getPos().x,this.chosenDest.getPos().y).getFP());
		return str.toString();
	}
	
}
