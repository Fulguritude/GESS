package Gess.Core;

public enum NeighborHood {
	TLeC, //top left corner 2*2
	TMid, //top middle 3*2
	TRiC, //top right corner 2*2
	MLeF, //Middle left Flank 2*3
	Norm, //Normal (middle) 3*3
	MRiF, //Middle Right Flank 2*3
	BLeC, //Bottom Left Corner 2*2
	BMid, //Bottom Middle 3*2
	BRiC  //Bottom Right Corner 2*2
}
