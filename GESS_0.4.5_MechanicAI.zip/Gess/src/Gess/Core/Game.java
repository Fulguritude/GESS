package Gess.Core;

import java.util.Scanner;

import Gess.Core.Board;
import Gess.Core.Stone;

public class Game {

	private int turn;
	private Board currentBd;
	private Board previousBd;
	private boolean gameOver;
	private Stone winner;
	public enum PlayerType { AI, HU}
	
	public Game() 
	{
		this.currentBd = Board.startConfig;
		this.turn = 0;
		this.gameOver = false;
	}
	public Game(String[] startConfig, Stone startPlayer)
	{
		if (!Game.isValidConfig(startConfig)) System.out.println("Invalid starting configuration, I'm'a let it crash."); 
		this.turn = startPlayer.equals(Stone.B) ? 0 : 1;
		this.currentBd = new Board(startConfig);
		this.gameOver = false;
	}
	static public boolean isValidConfig(String[] startConfig)
	{
		if (startConfig.length != 18) return false;
		for (int i=0 ; i <= 17; i++)
		{
			if (startConfig[i].length() != 18) return false;
		}
		return true;
	}
		
	public void play(PlayerType p1, PlayerType p2) 
	{
		Player P1;
		Player P2;
		Scanner sc = new Scanner(System.in);
		if (p1.equals(PlayerType.AI)) P1 = new AIPlayer(Stone.B);
		else						  P1 = new HUPlayer(Stone.B, sc);
		if (p2.equals(PlayerType.AI)) P2 = new AIPlayer(Stone.W);
		else						  P2 = new HUPlayer(Stone.W, sc);					  
		
		while (!gameOver)
		{
			System.out.print("\n\nTurn " + this.turn + " ; Player " + this.getStone() + " :\n");
			System.out.println(this.currentBd.toStartConfigString());
			if (this.turn % 2 == 0) P1.playTurn(this);
			else P2.playTurn(this);
		}
	}
	public void update(Board newBd)  
	{
		this.previousBd = this.currentBd;
		this.currentBd = newBd;
		this.gameOver = currentBd.checkWin(this.getStone());
		if (this.gameOver) {
			this.winner = this.getStone(); 
			System.out.println(currentBd.toGameString());
			System.out.println("AND THE WINNER IS.... PLAYER " + this.winner + " !!!");
		}
		else this.turn++;
	}
	
	public Stone getStone()
	{
		if (turn%2 == 0) return Stone.B;
		else 			 return Stone.W;
	}
	public Board getPreviousBd() 
	{
		return this.previousBd;
	}
	public Board getCurrentBd() 
	{
		return this.currentBd;
	}
}
